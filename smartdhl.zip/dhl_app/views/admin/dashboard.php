<div class="row">

    <div class="col-xs-12 form-group required">
       <p><h3>Welcome to Admin panel</h3></p>
    </div>


</div>

