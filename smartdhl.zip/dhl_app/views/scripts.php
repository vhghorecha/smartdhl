<script src="<?= RES_URL; ?>js/jquery.min.js"></script>
<script src="<?= RES_URL; ?>js/jquery.validate.min.js"></script>
<script src="<?= RES_URL; ?>js/bootstrap.min.js"></script>
<script src="<?= RES_URL; ?>js/jquery.dataTables.min.js"></script>
<script src="<?= RES_URL; ?>js/dataTables.responsive.js"></script>
<script src="<?= RES_URL; ?>js/jquery.columnFilter.js"></script>
<script src="<?= RES_URL; ?>js/script.js"></script>
<script type="text/javascript">
    var txtsearch = '<input type="text" placeholder="Search" style="width:100%" />';
    var datesearch = '<input type="text" placeholder="Search" style="width:100%" class="tdatepicker" />';
</script>