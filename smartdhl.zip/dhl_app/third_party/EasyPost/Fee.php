<?php

namespace EasyPost;

class Fee extends Resource
{
    
}

