<?php

namespace EasyPost;

class PostageLabel extends Resource
{
    
}

